const Competitor = require('../models/Competitor');

module.exports = {
    getIndex: function (req, res) {
        // TODO: Implement me
    },
    getCreate: function (req, res) {
        // TODO: Implement me
    },
    postCreate: function (req, res) {
        // TODO: Implement me
    },
    getEdit: function (req, res) {
        // TODO: Implement me
    },
    postEdit: function (req, res) {
        // TODO: Implement me
    },
    getDelete: function (req, res) {
        // TODO: Implement me
    },
    postDelete: function (req, res) {
        // TODO: Implement me
    }
};