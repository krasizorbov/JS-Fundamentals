const mongoose = require('mongoose');

const mountaineerSchema = new mongoose.Schema({
    //TODO
});

const Mountaineer = mongoose.model('Mountaineer', mountaineerSchema);
module.exports = Mountaineer;